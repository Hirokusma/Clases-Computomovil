//: [Previous](@previous)

import Foundation
struct Temperature
{
    static var boilingPoint = 100
    var celsius: Double
    static func hello (){
        print ("Hola")
    }
    
}

let instance = Temperature(celsius: 300.0)
let instance2 = Temperature(celsius: 200.0)
instance.celsius
Temperature.boilingPoint = 500
// no hay firma por static por las clases y la variable de tipo de dato por lo que usamos el punto y no instancia osea los parentesis
//Los estructores son solo con las que no son estaticas osea si puedo abrir el pàrentesis

instance2.celsius //nivelinstancia solo usa celsius por que no tiene estatico
Temperature.boilingPoint //nivel tipo
Temperature.hello() //niveltipo

