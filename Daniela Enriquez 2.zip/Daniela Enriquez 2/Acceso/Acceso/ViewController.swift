//
//  ViewController.swift
//  Acceso
//
//  Created by 2019-2 on 4/3/19.
//  Copyright © 2019 2019-2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
    }

}

