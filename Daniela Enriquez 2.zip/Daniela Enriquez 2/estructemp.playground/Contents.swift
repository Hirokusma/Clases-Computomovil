import UIKit
struct Temperature
{
    var celsius: Double
    var fahrenheit:Double
    {
        return celsius * 1.8 + 32
    }
    var kelvin:Double
    {
        return celsius + 273.15
    }
    
}
var instancia1 = Temperature(celsius: 100)
instancia1.fahrenheit
instancia1.celsius
instancia1.kelvin
instancia1.celsius = 120
instancia1.fahrenheit
instancia1.celsius
instancia1.kelvin
