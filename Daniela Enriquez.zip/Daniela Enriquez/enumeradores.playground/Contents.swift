enum comida
{
    case pasta
    case hamburguesa
    case sopa
    
    // conesto el usuario no puede escoger alguna otra cosa
}

//Le damos instancia y si despues de comida.pescado (algo que no esta) entonces marca error
let restaurante = comida.hamburguesa

//Otra forma de hacer un enumerador

enum comidaDos
{
    case pescado, pollo, nuggets
}

var eleccion: comidaDos
eleccion =  .nuggets //colocamos una variable que nos permite evitar volver a colocar de donde viene (antes de .)


enum LunchChoice
{
    case pasta, burger, soup
}

let myLunch = LunchChoice.burger
let yourLunch = LunchChoice.burger

if myLunch == yourLunch
{
    "Vamos a almorzar lo mismo"
}
else
{
    "¿Puedo probar tu comida?"
}


let choice = LunchChoice.burger
switch choice
{
case.pasta: 1
case.burger: 2
case.soup: 3
}

enum calidad
{
    case bueno, regular, malo, pesimo
}
let quality = calidad.bueno

switch quality {
case .pesimo:
    print ("No es aceptable")
case .malo:
    print("No es suficiente")
case .regular, .bueno:
    print("Bien, lo acepto")
}
