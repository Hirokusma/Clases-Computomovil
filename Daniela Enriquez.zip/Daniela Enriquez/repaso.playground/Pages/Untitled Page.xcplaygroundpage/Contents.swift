import UIKit

var str = "Hello, playground"

struct Book {
    let name: String
    let publicationYear: Int? //Opcional
    
}

let firstHarryPotter = Book (name: "Harry Potter and the Sorcerer's Stone", publicationYear: 1997)
let secondHarrypotter = Book (name: "Harry Potter and the Chamber of Secrets", publicationYear: 1998)
let last = Book (name: "Harry Potter again", publicationYear: nil)

let books = [firstHarryPotter, secondHarrypotter, last]

for item in books {
    if let constant = item.publicationYear //Sacar la opcional
    {
        print(constant)
    }
    //1print("Nombre del libro: \(item.name) \n")  //El punto es para tener acceso a los atributos
   //1 if (item.publicationYear != nil){
       //1 print("El año de publicación: \(item.publicationYear!)") //El signo de admiración ayuda a decirle ya se manejo la exepción }
    //1else {
        //print("No tiene fecha de publicación")}
}
