//: [Previous](@previous)

import Foundation

var str = "Hello, playground"


func
printFullName (FirstName)
