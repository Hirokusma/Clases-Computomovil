//
//  ViewController.swift
//  miPrimeraApp
//
//  Created by Macbook on 3/4/19.
//  Copyright © 2019 Biblioteca. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func buttonTapped(_ sender: UIButton) {
        Label1.text = "Hola"
        view.backgroundColor = UIColor.green
        
    }
    
    @IBOutlet weak var Label1: UILabel!
    
    @IBOutlet weak var imagen: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
}

