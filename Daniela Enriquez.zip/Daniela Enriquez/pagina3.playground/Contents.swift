import Foundation

let arreglo: [Any]=["Nombre", 12.0,1,true]


func recorrer (arregloCualquiera: [Any]) { //Any va entre corchetes por que es un arreglo, no un solo Any
    
    for item in arregloCualquiera{
        if let item = item as? String{ //as?=una prueba del tipo de dato si no es regresa un nil, as! no pregunta, sino se indica obliogatoria a que sea cadena
            
        print("\(item) es una cadena")
    }

       else if let item = item as? Double{
        print("\(item) es una cadena")
    }
        else if let item = item as? Int{
            print("\(item) es una cadena")
}
        else if let item = item as? Bool{
            print("\(item) es una cadena")
        }
    }
}

recorrer(arregloCualquiera: arreglo)
