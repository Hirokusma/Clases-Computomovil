import UIKit
struct Persona
{
    
    // let age = 21 no todas las personas tendran la misma edad, por lo tanto
    //Lo mismo con los demas datos
    let age: Int
    let months: Int
    let name: String
    let firstname: String
    let lastname: String
    let birthday: Date //En el anterior la andabamos inicializando
    let isHappy = true
    //hardcore o literal donde se pone el valor directamente
    
    func hello(name nombre:String) -> String
    {
        let saludo = "Hola" + nombre //propiedad local
        return saludo
    }
    }
    let person = Persona (age: 38, months: 11, name: "Jose", firstname: "Perez", lastname: "Coco", birthday: Date()) //Solo en estructuras, en objetos lo tenemos que hacer nosotros
     person.firstname



    


