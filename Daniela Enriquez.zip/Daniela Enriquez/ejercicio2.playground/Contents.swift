import UIKit

struct Book
{
    let name: String
    let año: Int?
    init?(name:String,año:Int?) {
        if (name == "La novela")
        {
            return nil
        }
        self.name = name
        self.año = año
        
    }
    
}
let first = Book(name: "Harry Potter 1", año: 1997)
let second = Book (name: "Harry Potter 2", año: 1998)
let last = Book (name: "Harry Potter 3", año: nil)
let bookNil = Book(name: "La novela", año: nil)
let books = [first,second,last, bookNil]
func recorreArreglo (){
for item in books{
    guard let publicationYear = item?.año else{

            print ("No pude ni desenvolver la estructura ni el año del libro")
        return
        }
    print ("El año de publicación: \(año)")
    }
}
recogeArreglo ()

