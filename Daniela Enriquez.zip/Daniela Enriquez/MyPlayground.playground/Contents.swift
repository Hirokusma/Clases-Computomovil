true

false

//Menor o igual
1 <= 2
2 <= 2
3 <= 2

//Mayor o igual
1 >= 2
2 >= 2
3 >= 2

var video = 8
if video < 10
{
    print("El video dura mucho")
    
}
else if video > 500
{
    print("Está super largo")
}
else
{
    print ("No está tan largo")
}

//Instancias
var hola = "Hola, buenos días"
var numero = 0
//let dia = Date () // regresa la fecha

//Métodos
hola.hasPrefix("Hola") //Dice si esta cadena tiene un parametro que ya está
hola.hasPrefix("hola") //Con cambioar una letra ya nos dice falso ->
//numero.hasPrefix // No es método de la variable


//Propiedades
hola.isEmpty //nuestra instancia tiene valor o no y no es parte de las propiedades de la variable por lo tanto da falso ->
hola.removeAll() //es método por que hizo algo
hola.isEmpty

/////////////////
var devices = ["iPad", "iMac", "iPhone", "iPod"]

devices[1] //muestra lugar del arreglo de arriba (indices) los arreglos siempre tendra indices que podremos manipular

let numeros = [6,4,3,5,6,2,5]
print ("Yo tengo un \(devices[0])")

let friends = ["Luis", "Pedro", "Abner", "Sandra", "Alex"]
for friend in friends
{
    let sparklyFriend = "✨\(friend)✨"
    print ("¿Oye,\(sparklyFriend), te invito a mi fiesta el viernes!")
}
print ("LISTO, INVITASTE A TODOS TUS AMIGOS")

devices.append("mac mini") //Decalaras devices como var, antes era let en la parte de la invitación
devices.insert("apple tv", at: 0)
devices += ["macbook", "macbook pro", "iphone XR"]
devices.remove(at: 0)
devices
devices.removeFirst()
devices.removeLast()

var flavors = ["Chocolate", "Vainilla", "Fresa", "Pistacho", "Chocolate con malvavisco"]

//Sustituye en el lugar que seleccionas
flavors[0]="Frambuesa"
flavors[4]="Limón"
flavors
