//
//  ResultadoTriviaViewController.swift
//  segundo_examen_parcial
//
//  Created by Macbook on 5/14/19.
//  Copyright © 2019 FI. All rights reserved.
//

import UIKit

class ResultadoTriviaViewController: UIViewController {
    

    @IBOutlet weak var navItem: UINavigationItem!
    @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var texto: UILabel!
    @IBOutlet weak var codigo: UIButton!
    var exito:Bool!
    let imagenExito = UIImage(imageLiteralResourceName: "trivia-exitosa")
    let imagenFallo = UIImage(imageLiteralResourceName: "trivia-fallida")
    let textoExito = "Grab that cash with both hands and make a stash"
    let textoFallo = "Don't give in, without a fight"
    let botonExitoTexto = "Promo Code"
    let botonFalloTexto = "Intente de nuevo"
    let navTituloExito = "Trivia Exitosa :)"
    let navTituloFallo = "Trivia Fallida :("
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(exito) {
            imagen.image = imagenExito
            texto.text = textoExito
            codigo.setTitle(botonExitoTexto, for: .normal)
            navItem.title = navTituloExito
        } else {
            imagen.image = imagenFallo
            texto.text = textoFallo
            codigo.setTitle(botonFalloTexto, for: .normal)
            navItem.title = navTituloFallo
        }
        
    }
    @IBAction func regresar(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
}
