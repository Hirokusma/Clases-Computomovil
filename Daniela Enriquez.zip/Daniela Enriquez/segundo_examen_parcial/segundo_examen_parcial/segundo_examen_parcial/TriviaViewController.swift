//
//  TriviaViewController.swift
//  segundo_examen_parcial
//
//  Created by Macbook on 5/14/19.
//  Copyright © 2019 FI. All rights reserved.
//

import UIKit

class TriviaViewController: UIViewController {

    @IBOutlet weak var switch1: UISwitch!
    @IBOutlet weak var switch2: UISwitch!
    @IBOutlet weak var switch3: UISwitch!
    var exito:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let resultado = segue.destination as? ResultadoTriviaViewController else { return }
        resultado.exito = exito
    }


    @IBAction func revisarTrivia(_ sender: UIButton) {
        if(!switch1.isOn && switch2.isOn && switch3.isOn) {
            exito = true
        }else {
            exito = false
        }
        performSegue(withIdentifier: "triviaSegue", sender: self)
    }

}
