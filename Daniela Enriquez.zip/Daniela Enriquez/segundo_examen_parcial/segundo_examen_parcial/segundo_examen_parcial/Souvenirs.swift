//
//  Souvenirs.swift
//  segundo_examen_parcial
//
//  Created by Macbook on 4/29/19.
//  Copyright © 2019 FI. All rights reserved.
//

import UIKit

class SouvenirsController: UIViewController {
    
    let promoCode = "Promo Code"
    
    @IBOutlet weak var it1: UILabel!
    @IBOutlet weak var it2: UILabel!
    @IBOutlet weak var steper1: UIStepper!
    @IBOutlet weak var steped2: UIStepper!
    @IBOutlet weak var text: UITextField!
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let compra = segue.destination as? CompraController else { return }
        var precio = 700*steper1.value + 200*steped2.value
        if(text.text == promoCode) {
            precio = precio / 2
        }
        compra.precio = precio
    }
    
    @IBAction func steped1(_ sender: UIStepper) {
        it1.text = String(Int(steper1.value))
    }
    @IBAction func steped2(_ sender: UIStepper) {
        it2.text = String(Int(steped2.value))
    }
    @IBAction func button(_ sender: UIButton) {
        if(text.text == "" || text.text == promoCode) {
            performSegue(withIdentifier: "compra", sender: self)
        } else {
            let alert = UIAlertController(title: "Error", message: "Código incorrecto.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("Error", comment: "Error"), style: .default, handler: { _ in
                NSLog("The \"Error\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)

        }
    }
}
