//
//  DiscoViewController.swift
//  segundo_examen_parcial
//
//  Created by Macbook on 5/14/19.
//  Copyright © 2019 FI. All rights reserved.
//

import UIKit

class DiscoViewController: UIViewController {
    
    let discografia = ["The dark side of the moon", "The wall", "Wish you were here"]
    let años = ["1973", "1979", "1975"]
    let imagenes = ["disco-1", "disco-2", "disco-3"]
    let canciones = [
        "Money \t 1:07 \t $15.00\nBreathe \t 2:49 \t $15.00\nTime \t 3:45 \t $15.00\n",
        "In the Flesh?\t 3:18\t $15.00\nThe Thin Ice \t 2:36 \t $15.00\nHey You \t 3:15 \t $15.00\n",
        "Wish You Were Here \t 13:21 \t $15.00\nWelcome to the Machine \t 7:31 \t $15.00\nShine On You Crazy \t 5:07 \t $15.00\n"]
    let precios = ["150.00", "180.00", "120.00"]
    
    let colores = [
        "negro": UIColor(displayP3Red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0),
        "blanco": UIColor(displayP3Red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0),
        "wall": UIColor(displayP3Red: 255/255, green: 253/255, blue: 241/255, alpha: 1.0),
        "rojo": UIColor(red: 211/255, green: 57/255, blue: 52/255, alpha: 1.0),
        "cielo": UIColor(red: 163/255, green: 193/255, blue: 217/255, alpha: 1.0),
    ]
    
    @IBOutlet weak var titulo: UILabel!
    @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var año: UILabel!
    @IBOutlet weak var informacion: UITextView!
    @IBOutlet weak var precio: UILabel!
    @IBOutlet var backgroundView: UIView!
    @IBOutlet weak var label: UILabel!
    
    var miIndex:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titulo.text = discografia[miIndex]
        imagen.image = UIImage(imageLiteralResourceName: imagenes[miIndex])
        año.text = años[miIndex]
        informacion.text = canciones[miIndex]
        precio.text = precios[miIndex]
        if(miIndex == 0) {
            backgroundView.backgroundColor = colores["negro"]
            titulo.textColor = colores["blanco"]
            año.textColor = colores["blanco"]
            informacion.textColor = colores["blanco"]
            informacion.backgroundColor = colores["negro"]
            precio.textColor = colores["blanco"]
            label.textColor = colores["blanco"]
        } else if(miIndex == 1) {
            backgroundView.backgroundColor = colores["wall"]
            titulo.textColor = colores["rojo"]
            año.textColor = colores["rojo"]
            informacion.textColor = colores["rojo"]
            informacion.backgroundColor = colores["wall"]
            precio.textColor = colores["rojo"]
            label.textColor = colores["rojo"]
        } else {
            backgroundView.backgroundColor = colores["cielo"]
            informacion.backgroundColor = colores["cielo"]
            titulo.textColor = colores["blanco"]
            año.textColor = colores["blanco"]
            informacion.textColor = colores["blanco"]
            precio.textColor = colores["blanco"]
            label.textColor = colores["blanco"]
        }

        // Do any additional setup after loading the view.
    }

}
