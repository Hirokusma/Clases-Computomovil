enum comida
{
    case pasta
    case hamburguesa
    case sopa
}

let restaurante = comida.hamburguesa



enum comidaDos
{
    case pescado, pollo, nuggets
}


var eleccion : comidaDos
eleccion = .nuggets


enum LunchChoice
{
    case pasta, burger, soup
}
let myLunch = LunchChoice.burger
let yourLunch = LunchChoice.burger

if myLunch == yourLunch
{
    "Vamos a almorzar lo mismo"
}
else
{
    "¿Puedo probar tu comida?"
}
