//
//  ViewController.swift
//  examen
//
//  Created by 2019-2 on 4/24/19.
//  Copyright © 2019 2019-2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var text: UITextField!
    
    @IBOutlet weak var navigationbar: UINavigationItem!
    
    
    @IBAction func boton(_ sender: Any) {
        navigationbar.title=text.text
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

