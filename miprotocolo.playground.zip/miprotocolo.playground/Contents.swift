import UIKit

class Shoe:CustomStringConvertible, Equatable, Comparable{
    static func < (lhs: Shoe, rhs: Shoe) -> Bool {
        if lhs.size < rhs.size
        {
            return true
            
        }
        return false
    }
    
    static func == (lhs: Shoe, rhs: Shoe) -> Bool {
        if lhs.size == rhs.size
        {
            return true
        }
        return false
    }
    // el metodo se llama == he idica que lo puedes usar
    
    var description: String{
        return "El zapato es (color: \(color) size: \(size) hasLaces: \(hasLaces))"
    }
let color: String
let size: Int
let hasLaces: Bool
    init (color: String, size:Int, hasLaces:Bool){

    self.color = color
    self.size = size
    self.hasLaces = hasLaces
    }
}
let zapato = Shoe (color: "Cafe", size: 18, hasLaces: false)
let huarache = Shoe (color: "Blanco", size: 18, hasLaces: false)
print(zapato)
print (huarache)
zapato == huarache
zapato < huarache
