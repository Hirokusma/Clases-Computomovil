//
//  ViewController.swift
//  Navegacion
//
//  Created by Macbook on 4/1/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func unwindToRed(for unwindSegue: UIStoryboardSegue) //unwindToRed se puede poner como se quiera.
    {
    }
    }


